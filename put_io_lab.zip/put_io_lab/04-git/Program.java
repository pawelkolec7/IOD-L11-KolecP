public class Hello {
    public static void main(String[] args){
        System.out.print("Hello World");
        System.out.print("Pierwsza zmiana");

        int a = 4;
        int b = 4;
        int c = a + b;
        System.out.println("The sum of " + a + " and " + b + " is: " + c);
        
    }
}